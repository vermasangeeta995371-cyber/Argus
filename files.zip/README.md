# Python Discord Bot (starter)

This is a minimal starter Discord bot using discord.py (v2+). It includes:
- prefix commands (e.g. `!ping`)
- slash commands (e.g. `/hello`)
- example moderation commands (kick/ban) as both prefix and slash commands
- extension (cog) loading

Requirements
- Python 3.10+
- A Discord application with a bot token (see steps below)

Setup
1. Clone/copy the project files into a folder.
2. Create a Discord application and bot:
   - https://discord.com/developers/applications
   - Add a Bot, copy the token.
   - Enable "Message Content Intent" if you want to read message content (required for prefix message commands that inspect message content).
3. Create a `.env` file from `.env.example` and fill in values:
   - DISCORD_TOKEN: your bot token
   - CLIENT_ID: the application (client) id
   - GUILD_ID (optional for faster slash command testing): your dev server id
4. Install dependencies: